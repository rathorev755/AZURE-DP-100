import os
import logging
import pandas as pd
import uuid
from dotenv import load_dotenv
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.ai.ml import MLClient, Input, load_component
from azure.ai.ml.entities import AmlCompute, Environment, ManagedOnlineEndpoint, ManagedOnlineDeployment
from azure.ai.ml.dsl import pipeline
from azure.core.exceptions import ResourceNotFoundError,ClientAuthenticationError
from azure.ai.ml import command
from azure.ai.ml import Input, Output,dsl
import uuid


# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("app.log"),  # Write logs to 'app.log'
        logging.StreamHandler()         # Also print logs to the console
    ]
)


logger = logging.getLogger(__name__)

# Initialize DefaultAzureCredential
try:
    credential = DefaultAzureCredential()
except ClientAuthenticationError as ex:
    logger.error(f"Failed to authenticate Azure credentials: {ex}")
    raise

# Load Key Vault details
keyVaultName = os.getenv("KEY_VAULT_NAME")

# keyVaultName = "snow755wss0305478416"
if not keyVaultName:
    logger.error("Key Vault name is not set in environment variables.")
    raise ValueError("Key Vault name is missing.")

key_vault_url = f"https://{keyVaultName}.vault.azure.net"

# Initialize the SecretClient
try:
    secret_client = SecretClient(vault_url=key_vault_url, credential=credential)
    logger.info("Connected to Azure Key Vault.")
except Exception as ex:
    logger.error(f"Error connecting to Azure Key Vault: {ex}")
    raise

# Retrieve secrets with caching
secrets_cache = {}

def get_secret(secret_name):
    if secret_name in secrets_cache:
        return secrets_cache[secret_name]
    try:
        secret_value = secret_client.get_secret(secret_name).value
        secrets_cache[secret_name] = secret_value
        return secret_value
    except ResourceNotFoundError:
        logger.error(f"Secret '{secret_name}' not found in Key Vault.")
        raise
    except Exception as ex:
        logger.error(f"Error retrieving secret '{secret_name}': {ex}")
        raise
   

try:
    subscription_id = get_secret("subscriptionid")
    resource_group = get_secret("resource-group")
    workspace = get_secret("workspace-name")
    logger.info("Secrets retrieved successfully.")
except Exception as ex:
    logger.error(f"Error retrieving secrets from Azure Key Vault: {ex}")
    raise

# Initialize MLClient
try:
    ml_client = MLClient(
        credential=credential,
        subscription_id=subscription_id,
        resource_group_name=resource_group,
        workspace_name=workspace,
    )
    logger.info("MLClient initialized successfully.")
except Exception as ex:
    logger.error(f"Error initializing MLClient: {ex}")
    raise

# Retrieve an already attached Azure Machine Learning Compute.
# specify aml compute name.
cluster_name = os.getenv("COMPUTE_CLUSTER", "cpu-cluster")

try:
    compute_target = ml_client.compute.get(cluster_name)
    logger.info(f"Using existing compute cluster: {cluster_name}")
except ResourceNotFoundError:
    logger.info("Creating a new CPU compute cluster...")
    compute = AmlCompute(
        name=cluster_name, size="STANDARD_D2_V2", min_instances=0, max_instances=4
    )
    compute_target = ml_client.compute.begin_create_or_update(compute).result()
    logger.info(f"Compute cluster created: {cluster_name}")
print(ml_client.compute.get(cluster_name))


dependencies_dir = "./dependencies_dir"
custom_env_name = "aml-scikit-learn_755"
conda_path = os.path.join(dependencies_dir, "conda.yml")
if not os.path.exists(conda_path):
    logger.error(f"Conda file missing: {conda_path}")
    raise FileNotFoundError(f"{conda_path} not found.")
try:
    # Check if the environment already exists
    custom_env  = ml_client.environments.get(custom_env_name)
    print(f"Environment '{custom_env_name}' already exists. Skipping creation.")
    custom_job_env = custom_env 
except Exception as e:
    logger.info(f"Creating environment {custom_env_name}...")
    # If the environment does not exist, create it
    print(f"Environment '{custom_env_name}' does not exist. Creating it...")
    custom_env  = Environment(
        name=custom_env_name,
        description="Custom environment for Credit Card Defaults job",
        tags={"scikit-learn": "1.0.2"},
        conda_file=conda_path,
        image="mcr.microsoft.com/azureml/openmpi4.1.0-ubuntu20.04:latest",
    )
    custom_env  = ml_client.environments.create_or_update(custom_env )
    logger.info(f"Environment {custom_env_name} created.")
    print(f"Environment '{custom_env_name}' created successfully.")


# List and log environments
for env in ml_client.environments.list():
    logger.info(f"Environment: {env.name} | Version: {env.version} | Tags: {env.tags}")

# Load dataset
try:
    credit_data = ml_client.data.get(name="credit-card", version="cleaned2024.12.12.024555")
    credit_df = pd.read_parquet(credit_data.path)
    logger.info("Dataset loaded successfully.")
except Exception as ex:
    logger.error(f"Error loading dataset: {ex}")
    raise



data_prep_src_dir = "./components/data_prep"

data_prep_component = command(
    name="data_prep_credit_defaults",
    display_name="Data preparation for training",
    description="reads a .xl input, split the input to train and test",
    inputs={
        "data": Input(type="uri_folder"),
        "test_train_ratio": Input(type="number"),
    },
    outputs=dict(
        train_data=Output(type="uri_folder", mode="rw_mount"),
        test_data=Output(type="uri_folder", mode="rw_mount"),
    ),
    # The source folder of the component
    code=data_prep_src_dir,
    command="""python data_prep.py \
            --data ${{inputs.data}} --test_train_ratio ${{inputs.test_train_ratio}} \
            --train_data ${{outputs.train_data}} --test_data ${{outputs.test_data}} \
            """,
    environment=f"{custom_env.name}:{custom_env.version}",
)
# Now we register the component to the workspace
data_prep_component = ml_client.create_or_update(data_prep_component.component)

# Create (register) the component in your workspace
print(
    f"Component {data_prep_component.name} with Version {data_prep_component.version} is registered"
)

# importing the Component Package
from azure.ai.ml import load_component
train_src_dir = "./components/train"
# Loading the component from the yml file
train_component = load_component(source=os.path.join(train_src_dir, "train.yml"))

# Now we register the component to the workspace
train_component = ml_client.create_or_update(train_component)

# Create (register) the component in your workspace
print(
    f"Component {train_component.name} with Version {train_component.version} is registered"
)

# the dsl decorator tells the sdk that we are defining an Azure Machine Learning pipeline

print("####################################################################################")

@dsl.pipeline(
    compute="cpu-cluster",  # "serverless" value runs pipeline on serverless compute
    description="E2E data_perp-train pipeline",
    cache=True,
)
def credit_defaults_pipeline(
    pipeline_job_data_input,
    pipeline_job_test_train_ratio,
    pipeline_job_learning_rate,
    pipeline_job_registered_model_name,
):
    # using data_prep_function like a python call with its own inputs
    data_prep_job = data_prep_component(
        data=pipeline_job_data_input,
        test_train_ratio=pipeline_job_test_train_ratio,
    )

    # using train_func like a python call with its own inputs
    train_job = train_component(
        train_data=data_prep_job.outputs.train_data,  # note: using outputs from previous step
        test_data=data_prep_job.outputs.test_data,  # note: using outputs from previous step
        learning_rate=pipeline_job_learning_rate,  # note: using a pipeline input as parameter
        registered_model_name=pipeline_job_registered_model_name,
    )

    # a pipeline returns a dictionary of outputs
    # keys will code for the pipeline output identifier
    return {
        "pipeline_job_train_data": data_prep_job.outputs.train_data,
        "pipeline_job_test_data": data_prep_job.outputs.test_data,
    }

credit_data = ml_client.data.get(name="credit-card", version="initial")
print(f"Data asset URI: {credit_data.path}")
registered_model_name = "credit_defaults_model"
input_data = Input(type="uri_file", path="azureml://subscriptions/cbea065c-379a-4b0b-afd2-e62026886cdf/resourcegroups/SNOW_755_RGG/workspaces/SNOW_755_WSS/datastores/workspaceblobstore/paths/LocalUpload/86095eb38b6df4af29ff5001bb0679b6/cleaned-credit-card.parquet")
# Let's instantiate the pipeline with the parameters of our choice
pipeline = credit_defaults_pipeline(
    pipeline_job_data_input=Input(type="uri_file", path=credit_data.path),
    pipeline_job_test_train_ratio=0.25,
    pipeline_job_learning_rate=0.05,
    pipeline_job_registered_model_name=registered_model_name,
)
print("####################################################################################")
# submit the pipeline job
pipeline_job = ml_client.jobs.create_or_update(
    pipeline,
    # Project's name
    experiment_name="e2e_registered_components",
)
ml_client.jobs.stream(pipeline_job.name)


# refresh the latest status of the job after streaming
returned_job = ml_client.jobs.get(name=pipeline_job.name)

if returned_job.status == "Completed":
    print("Pipeline job completed.")
print("###############################################")

# Create a unique name for the endpoint
online_endpoint_name = "credit-endpoint-" + str(uuid.uuid4())[:8]
endpoint = ManagedOnlineEndpoint(
    name=online_endpoint_name,
    description="this is an online endpoint",
    auth_mode="key",
    tags={
        "training_dataset": "credit_defaults",
    },
)

endpoint = ml_client.online_endpoints.begin_create_or_update(endpoint).result()

# Choose the latest version of our registered model for deployment
model = ml_client.models.get(name="credit_defaults_model", version="3")
# List models by name and sort by version in descending order
models = ml_client.models.list(name=registered_model_name)

# Get the latest model (the first in the sorted list)
latest_model = max(models, key=lambda m: int(m.version), default=None)

if latest_model:
    print(f"Latest model version: {latest_model.version}")
    print(f"Model path: {latest_model.path}")
else:
    print(f"No models found with name '{registered_model_name}'")
blue_deployment = ManagedOnlineDeployment(
    name="blue",
    endpoint_name=online_endpoint_name,
    model=latest_model.id,
    instance_type="Standard_D4ds_v5",
    instance_count=1,
)
# create the online deployment
blue_deployment = ml_client.online_deployments.begin_create_or_update(blue_deployment).result()
# blue deployment takes 100% traffic
# expect the deployment to take approximately 8 to 10 minutes.
endpoint.traffic = {"blue": 100}
ml_client.online_endpoints.begin_create_or_update(endpoint).result()
# return an object that contains metadata for the endpoint
endpoint = ml_client.online_endpoints.get(name=online_endpoint_name)
# print a selection of the endpoint's metadata
print(
    f"Name: {endpoint.name}\nStatus: {endpoint.provisioning_state}\nDescription: {endpoint.description}"
)
logger.info(f"Endpoint {online_endpoint_name} deployed successfully.")