import argparse
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential
from azure.ai.ml.entities import ManagedOnlineDeployment, ManagedOnlineEndpoint, Model

# Argument parsing
parser = argparse.ArgumentParser()
parser.add_argument("--model_path",  required=True, help="Path to the trained model (URI folder or registered model name)")
parser.add_argument("--endpoint_name", type=str, required=True, help="Name of the endpoint to deploy the model")
parser.add_argument("--instance_type", type=str, required=True, help="Compute instance type")
parser.add_argument("--instance_count", type=int, required=True, help="Number of instances for deployment")
args = parser.parse_args()

# Initialize MLClient
credential = DefaultAzureCredential()
ml_client = MLClient.from_config(credential)

# Define or get the existing endpoint
try:
    endpoint = ml_client.online_endpoints.get(args.endpoint_name)
    print(f"Endpoint {args.endpoint_name} found, proceeding to update.")
except Exception as e:
    print(f"Endpoint {args.endpoint_name} not found, creating a new one.")
    endpoint = ManagedOnlineEndpoint(
        name=args.endpoint_name,
        description="Endpoint for automated pipeline deployment",
        auth_mode="key",
        tags={
                "training_dataset": "credit_defaults",
             },
    )
    endpoint = ml_client.online_endpoints.begin_create_or_update(endpoint).result()

# # Check if model_path is a URI folder or a registered model
# if args.model_path.startswith("azureml://"):
#     # If model path is a URI folder, use it as a URI folder reference
#     model = Model(path=args.model_path)  # Create Model entity with path
# else:
#     # Otherwise, it's a registered model name
#     model = Model(name=args.model_path)  # Use the model name for registered model

# Define deployment
deployment = ManagedOnlineDeployment(
    name="blue",  # Can be dynamic or versioned if needed
    endpoint_name=args.endpoint_name,
    model=args.model_path,  # Using the model object (either URI or registered model)
    instance_type=args.instance_type,
    instance_count=args.instance_count,
)

# Create or update the deployment
deployment = ml_client.online_deployments.begin_create_or_update(deployment).result()

# Update endpoint traffic
endpoint.traffic = {"blue": 100}  # Routing all traffic to the blue deployment
ml_client.online_endpoints.begin_create_or_update(endpoint).result()

print(f"Deployment to endpoint {args.endpoint_name} successful!")
