import os
import argparse
import json
import pandas as pd
import mlflow
import mlflow.sklearn
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

def main():
    """Main function of the script."""
    # input and output arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", help="path to input data")
    parser.add_argument("--test_train_ratio", type=float, required=False, default=0.25)
    parser.add_argument("--n_estimators", required=False, default=100, type=int)
    parser.add_argument("--learning_rate", required=False, default=0.1, type=float)
    parser.add_argument("--registered_model_name", type=str, help="model name")
    parser.add_argument("--model_path",help ="model_output_uri_path")
    args = parser.parse_args()
   
    # Start Logging
    mlflow.start_run()

    # enable autologging
    mlflow.sklearn.autolog()

    ###################
    #<prepare the data>
    ###################
    print(" ".join(f"{k}={v}" for k, v in vars(args).items()))

    print("input data:", args.data)
    
    credit_df = pd.read_parquet(args.data)
    print(credit_df.head())
    print("$&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&#######################")

    mlflow.log_metric("num_samples", credit_df.shape[0])
    mlflow.log_metric("num_features", credit_df.shape[1] - 1)

    train_df, test_df = train_test_split(
        credit_df,
        test_size=0.25,
    )
    ####################
    #</prepare the data>
    ####################

    ##################
    #<train the model>
    ##################
    # Extracting the label column
    y_train = train_df.pop("default")

    # convert the dataframe values to array
    X_train = train_df.values

    # Extracting the label column
    y_test = test_df.pop("default")

    # convert the dataframe values to array
    X_test = test_df.values

    print(f"Training with data of shape {X_train.shape}")

    clf = GradientBoostingClassifier(
        n_estimators=args.n_estimators, learning_rate=args.learning_rate
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)

    print(classification_report(y_test, y_pred))
    ###################
    #</train the model>
    ###################

    ##########################
    #<save and register model>
    ##########################
    # Registering the model to the workspace
    print("Registering the model via MLFlow")
    mlflow.sklearn.log_model(
        sk_model=clf,
        registered_model_name=args.registered_model_name,
        artifact_path=args.registered_model_name,
    )

    model_uri = f"models:/{args.registered_model_name}/latest" 

     # Capture model URI after registering
    model_uri = f"models:/{args.registered_model_name}/latest"
    
    # Define output directory and save model URI to a file
    model_output = "./outputs/model_output"
    os.makedirs(model_output, exist_ok=True)
    model_info = {"model_uri": model_uri}
    
    # Save the model URI to the output path
    with open(os.path.join(model_output, "model_uri.json"), "w") as f:
        json.dump(model_info, f)
    
    print(f"Model registered with URI: {model_uri}")


    # Saving the model to a file
    # mlflow.sklearn.save_model(
    #     sk_model=clf,
    #     path=os.path.join(args.registered_model_name, "trained_model"),
    # )
    ###########################
    #</save and register model>
    ###########################

    # print("MLflow tracking URI:", mlflow.get_tracking_uri())

    # Stop Logging
    mlflow.end_run()

if __name__ == "__main__":
    main()
