from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize DefaultAzureCredential
credential = DefaultAzureCredential()

# Load Key Vault details
keyVaultName = "snow755wss0305478416"
if not keyVaultName:
    logger.error("Key Vault name is not set in environment variables.")
    raise ValueError("Key Vault name is missing.")

key_vault_url = f"https://{keyVaultName}.vault.azure.net"

# Initialize the SecretClient
try:
    secret_client = SecretClient(vault_url=key_vault_url, credential=credential)
    logger.info("Connected to Azure Key Vault.")
except Exception as ex:
    logger.error(f"Error connecting to Azure Key Vault: {ex}")
    raise

# Retrieve secrets with caching
secrets_cache = {}

def get_secret(secret_name):
    if secret_name in secrets_cache:
        return secrets_cache[secret_name]
    secret_value = secret_client.get_secret(secret_name).value
    secrets_cache[secret_name] = secret_value
    return secret_value

try:
    subscription_id = get_secret("subscriptionid")
    resource_group = get_secret("resource-group")
    workspace = get_secret("workspace-name")
    logger.info("Secrets retrieved successfully.")
except Exception as ex:
    logger.error(f"Error retrieving secrets from Azure Key Vault: {ex}")
    raise

# Initialize MLClient
try:
    ml_client = MLClient(
        credential=credential,
        subscription_id=subscription_id,
        resource_group_name=resource_group,
        workspace_name=workspace,
    )
    logger.info("MLClient initialized successfully.")
except Exception as ex:
    logger.error(f"Error initializing MLClient: {ex}")
    raise 

