import argparse
import pandas as pd
import os

def preprocess_data(input_path, output_path):
    # Load the input data
    print(f"Reading data from {input_path}...")
    data = pd.read_csv(input_path)

    # read in data again, this time using the 2nd row as the header
    # df = pd.read_csv(data_asset.path, header=1)
    # rename column
    data.rename(columns={"default payment next month": "default"}, inplace=True)
    # remove ID column
    data.drop("ID", axis=1, inplace=True)

    # Save the preprocessed data
    os.makedirs(output_path, exist_ok=True)
    output_file = os.path.join(output_path, "processed_data.csv")
    print(f"Saving preprocessed data to {output_file}...")
    data.to_csv(output_file, index=False)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_data", type=str, help="Path to input data")
    parser.add_argument("--output_data", type=str, help="Path to save processed data")
    args = parser.parse_args()

    preprocess_data(args.input_data, args.output_data)
